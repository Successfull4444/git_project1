import pygame
from random import choice, shuffle

screen_color = (255, 255, 150)
task_color = (0, 17, 142)
answers_color = (0, 17, 142)
score_color = (255, 17, 142)
score = 0


def delete_duplicates(this_list):
    new_list = []
    for element in this_list:
        if element not in new_list:
            new_list.append(element)
    return new_list


def show_and_check_task(screen1):
    x = choice(list(range(11, 100)))
    y = choice(list(range(11, 100)))
    answer = x * y
    summand = choice(list(range(1, 21)))
    wrong_answers_list = []
    for i in range(1, 15, 2):
        wrong_answers_list.append(answer - i * summand)
        wrong_answers_list.append(answer + i * summand)
    shuffle(wrong_answers_list)
    answers_list = wrong_answers_list[0:3]
    answers_list.append(answer)
    shuffle(answers_list)
    task = f"{x} x {y} =?"
    true_index = answers_list.index(answer)
    last_digit = str(answer)[- 1]
    answers_list = [str(number)[0:- 1] + last_digit for number in answers_list]

    draw(screen1, task, 300, 200, task_color)
    draw(screen1, answers_list[0], 260, 300, answers_color)
    draw(screen1, answers_list[1], 260, 360, answers_color)
    draw(screen1, answers_list[2], 400, 300, answers_color)
    draw(screen1, answers_list[3], 400, 360, answers_color)
    draw(screen1, f"Ваши очки: {round(score, 2)}", 500, 500, score_color)
    return true_index



def draw(screen1, task, text_x, text_y, color, frame_color=(62, 0, 255)):
    font = pygame.font.Font(None, 50)
    text = font.render(task, True, color)
    text_w = text.get_width()
    text_h = text.get_height()
    screen1.blit(text, (text_x, text_y))
    pygame.draw.rect(screen1, frame_color, (text_x - 10, text_y - 10,
                                           text_w + 20, text_h + 20), 3)
    return [text_x - 10, text_x - 10 + text_w + 20, text_y - 10, text_y - 10 + text_h + 20]


if __name__ == '__main__':
    pygame.init()
    size = width, height = 800, 600
    screen = pygame.display.set_mode(size)
    screen.fill(screen_color)
    #show_and_check_task(screen)
    pygame.display.flip()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEMOTION:
                pass
            if event.type == pygame.MOUSEBUTTONDOWN:
                # if ans1[0] <= event.pos[0] <= ans1[2] and ans1[0] <= event.pos[1] <= ans1[3] and true_index == 0:
                #     score += 1
                # elif ans2[0] <= event.pos[0] <= ans2[2] and ans2[0] <= event.pos[1] <= ans2[3] and true_index == 1:
                #     score += 1
                # elif ans3[0] <= event.pos[0] <= ans3[2] and ans3[0] <= event.pos[1] <= ans3[3] and true_index == 2:
                #     score += 1
                # elif ans4[0] <= event.pos[0] <= ans4[2] and ans4[0] <= event.pos[1] <= ans4[3] and true_index == 3:
                #     score += 1
                pass
            else:
                break
            screen.fill(screen_color)
            x = choice(list(range(11, 100)))
            y = choice(list(range(11, 100)))
            answer = x * y
            summand = choice(list(range(1, 21)))
            wrong_answers_list = []
            for i in range(1, 50, 1):
                wrong_answers_list.append(answer - i * summand)
                wrong_answers_list.append(answer + i * summand)
            shuffle(wrong_answers_list)
            last_digit = str(answer)[- 1]
            wrong_answers_list = [str(number)[0:- 1] + last_digit for number in wrong_answers_list]
            wrong_answers_list = delete_duplicates(wrong_answers_list)
            answers_list = wrong_answers_list[0:3]
            answers_list.append(answer)
            shuffle(answers_list)
            this_task = f"{x} x {y} =?"
            true_index = answers_list.index(answer)
            answers_list = [str(number) for number in answers_list]
            draw(screen, this_task, 300, 200, task_color)
            ans1 = draw(screen, answers_list[0], 260, 300, answers_color)
            ans2 = draw(screen, answers_list[1], 260, 360, answers_color)
            ans3 = draw(screen, answers_list[2], 400, 300, answers_color)
            ans4 = draw(screen, answers_list[3], 400, 360, answers_color)
            print(ans1)
            draw(screen, f"Ваши очки: {round(score, 2)}", 500, 500, score_color)
        pygame.display.flip()
    pygame.quit()
